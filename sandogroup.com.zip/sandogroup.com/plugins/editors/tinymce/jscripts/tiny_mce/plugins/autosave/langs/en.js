// EN lang variables
