// UK lang variables
