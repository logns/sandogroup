 $(document).ready(function(){

    $("#panelHandle").click(function() {
            var sidePanel = $("#sidePanel").css('right');
            //alert(sidePanel);
            if (sidePanel == '0px') {
                $("#sidePanel").animate( {
                    'right' : '-200px'
                }, 1000);
            } else {
                $("#sidePanel").animate( {
                    'right' : '0px'
                }, 1000);
            }
        });

    });
 
 jQuery(function($) {
     
       $('#slider-wrapper').slidesjs({
            navigation: {
            	active:true,
            	 effect: "slide"
            }
            
            
      });
      
      $('#testimonials-section').slidesjs({
            navigation:false,
             play: {
                auto: true,
                interval: 5000,
                effect: "slide"
             }
      });
      
       $('#featured-pumps-section').slidesjs({
            navigation:false,
              play: {
                auto: true,
                interval: 1000000,
                effect: "slide"
             }
            
      });


});

jQuery(function($){
    jQuery.fn.center = function () {
    this.css("position","fixed");
    this.css("bottom", "0px");
    this.css("left", Math.max(0, (($(window).width() - $(this).outerWidth()) / 2) +
    $(window).scrollLeft()) + "px");
    return this;
}
   
});


jQuery(function($){
$('.default-value').each(function() {
            var default_value = this.value;
            $(this).focus(function() {
                if (this.value == default_value) {
                    this.value = '';
                }
            });
            $(this).blur(function() {
                if (this.value == '') {
                    this.value = default_value;
                }
            });
        });
        
 $('#component-cta').center();       

});

function formSubmit(formID, displayMssgID){
    jQuery(function($){
        var val = $('#' + formID + ' :input').validateForm();
        var CDT = '&' + getTimeStamp(); 
        var qstring = $('#' + formID).serialize() + CDT;
        
        if (val) {
            if(formID === 'component-cta')
               {
                   $('#overlay').fadeIn();
                   $('#'+ displayMssgID).fadeIn();
               }
             
            $('#' + displayMssgID).html('<div class="process_img"> Registering your Request ... Please Wait ...</div> ');
            $.ajax( {
                url : "index.php",
                data : qstring,
                success : function(data) {
                    $('#' + displayMssgID).html('');
                    $('#' + displayMssgID).append(data);
                   window.setTimeout(function() {
                        $('#' + displayMssgID).html('');
                         if(formID === 'component-cta')
                             {    
                                $('#overlay').fadeOut();
                                $('#'+ displayMssgID).fadeOut();
                             }
                    }, 4000);
                }
            });
        }
    });
}

function getTimeStamp() {
    var currentTime = new Date();
    var day = currentTime.getDate();
    var month = currentTime.getMonth() + 1;		
    var year = currentTime.getFullYear();
    var hours = currentTime.getHours() + 1;
    var miniutes = currentTime.getMinutes() + 1;
    var seconds = currentTime.getSeconds() + 1;
    return (day + "-" + month + "-" + "-" + year + " " + hours + ":" + miniutes + ":" + seconds);
}